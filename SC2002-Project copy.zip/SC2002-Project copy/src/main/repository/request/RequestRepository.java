package main.repository.request;

import main.repository.Repository;

public class RequestRepository extends Repository {

	private String FILE_PATH;

	public RequestRepository() {
		// TODO - implement RequestRepository.RequestRepository
		throw new UnsupportedOperationException();
	}

	public RequestRepository getInstance() {
		// TODO - implement RequestRepository.getInstance
		throw new UnsupportedOperationException();
	}

	public String getFilePath() {
		// TODO - implement RequestRepository.getFilePath
		throw new UnsupportedOperationException();
	}

	public void setAll() {
		// TODO - implement RequestRepository.setAll
		throw new UnsupportedOperationException();
	}

}