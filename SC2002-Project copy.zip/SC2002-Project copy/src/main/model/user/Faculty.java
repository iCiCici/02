package main.model.user;

public enum Faculty {
    NA,
    NTU,
    ADM,
    EEE,
    NBS,
    SCSE,
    SSS
}
