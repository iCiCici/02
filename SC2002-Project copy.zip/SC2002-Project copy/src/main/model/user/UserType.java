package main.model.user;

public enum UserType {
    STUDENT,
    STAFF
}
