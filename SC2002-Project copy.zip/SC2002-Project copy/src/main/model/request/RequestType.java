package main.model.request;

public enum RequestType {
    ENQUIRY,
    SUGGESTION
}
