package main.controller.request;

public class StaffManager {

	/**
	 * 
	 * @param String
	 * @param parameter
	 * @param parameter2
	 */
	public void approveSuggestion(int String, int parameter, int parameter2) {
		// TODO - implement StaffManager.approveSuggestion
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param String
	 * @param parameter
	 * @param parameter2
	 */
	public void rejectSuggestion(int String, int parameter, int parameter2) {
		// TODO - implement StaffManager.rejectSuggestion
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param String
	 * @param parameter
	 * @param parameter2
	 */
	public void replyEnquiry(int String, int parameter, int parameter2) {
		// TODO - implement StaffManager.replyEnquiry
		throw new UnsupportedOperationException();
	}

	public List<Request> getAllRequest() {
		// TODO - implement StaffManager.getAllRequest
		throw new UnsupportedOperationException();
	}

	public List<Request> getPendingRequest() {
		// TODO - implement StaffManager.getPendingRequest
		throw new UnsupportedOperationException();
	}

}