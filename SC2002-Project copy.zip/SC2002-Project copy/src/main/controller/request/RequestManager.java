package main.controller.request;

public class RequestManager {

	public int Visibility;

	/**
	 * 
	 * @param visibility
	 */
	public void grantAccessToView(int visibility) {
		// TODO - implement RequestManager.grantAccessToView
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param String
	 */
	public Request getRequest(int String) {
		// TODO - implement RequestManager.getRequest
		throw new UnsupportedOperationException();
	}

	public String getNewRequestID() {
		// TODO - implement RequestManager.getNewRequestID
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Request
	 */
	public void approveRequest(int Request) {
		// TODO - implement RequestManager.approveRequest
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param String
	 */
	public void rejectRequest(int String) {
		// TODO - implement RequestManager.rejectRequest
		throw new UnsupportedOperationException();
	}

}