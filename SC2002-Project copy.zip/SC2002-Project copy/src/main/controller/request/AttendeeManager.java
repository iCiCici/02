package main.controller.request;

public class AttendeeManager {
}