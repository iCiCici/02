package main.controller.request;
import main.model.request.Request;
import main.repository.*;

public class CommManager {

	public void getPendingRequestByComm() {
		// TODO - implement CommManager.getPendingRequestByComm
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param String
	 */
	public List<Request> viewRequest(int String) {
		// TODO - implement CommManager.viewRequest
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Comm
	 */
	public List<Request> getAllRequestHistory(int Comm) {
		// TODO - implement CommManager.getAllRequestHistory
		throw new UnsupportedOperationException();
	}

}